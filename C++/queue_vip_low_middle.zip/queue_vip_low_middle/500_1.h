#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

int answer (int a, int b, char k);


#endif // LIB_H_INCLUDED
